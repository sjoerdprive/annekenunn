# WebModu start thema

Flexibel beginpunt voor WP websites.

## Tech

- Sage
- AlpineJS
- SCSS
- FontAwesome
- WebModu base styles

## Get started

```
wsl yarn dev
```

Soms zeikt yarn dat het geen bud shell script kan vinden. In dat geval terminal opnieuw opstarten. Mogelijk verplaatst de cd in de wsl zichzelf terug in de root van de workspace (VS code), oorzaak is niet zeker.

## To do

- Uhh
